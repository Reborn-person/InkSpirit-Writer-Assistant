@echo off
title AI Novel Writer Launcher
echo.
echo ========================================================
echo       AI Novel Writer Launcher
echo ========================================================
echo.

cd /d "%~dp0"

echo [1/3] Cleaning cache...
if exist .next (
    rd /s /q .next
    echo - Cache cleaned.
) else (
    echo - Cache is clean.
)

echo.
echo [2/3] Checking environment...
if not exist node_modules (
    echo - Installing dependencies...
    call npm install
) else (
    echo - Environment OK.
)

echo.
echo [3/3] Starting service...
echo.
echo --------------------------------------------------------
echo   Access URL: http://localhost:3000
echo   Browser will open automatically...
echo --------------------------------------------------------
echo.

:: Start browser in background immediately (1s delay to ensure process init)
start /b cmd /c "timeout /t 1 /nobreak >nul && start http://localhost:3000"

call npm run dev
pause
